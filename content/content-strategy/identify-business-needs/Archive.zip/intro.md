---
layout: intros/intro_with_nav
subtitle: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lorem mi, iaculis ut eleifend et, convallis et libero. Ut sed congue magna. Sed id bibendum felis. 
attrTitle1: Created by
attrValue1: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lorem mi, iaculis ut eleifend et, convallis et libero. Ut sed congue magna. Sed id bibendum felis. 
attrTitle2: Reviewed on
attrValue2: 4 September 2017
category: Content Strategy
---


## [3]Why Lorem ipsum dolor sit ame
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lorem mi, iaculis ut eleifend et, convallis et libero. Ut sed congue magna. Sed id bibendum felis. 
